from django.middleware.csrf import CsrfViewMiddleware


class CsrfAllowAllOriginsMiddleware(CsrfViewMiddleware):
    """CSRF middleware che accetta qualsiasi Origin/Referer.

    Utile in LAN/dev quando apri l'admin da IP/host diversi e non vuoi
    mantenere aggiornata CSRF_TRUSTED_ORIGINS.

    ATTENZIONE: abilitalo solo in ambienti di sviluppo/rete interna.
    """

    def _origin_verified(self, request):
        return True

    def _check_referer(self, request):
        # In HTTPS Django verifica anche il Referer. In modalità "allow all"
        # lo bypassiamo per coerenza.
        return
