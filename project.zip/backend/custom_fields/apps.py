from django.apps import AppConfig


class CustomFieldsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "custom_fields"
    verbose_name = "Campi custom"
