import * as React from "react";
import {
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Divider,
  Drawer,
  FormControl,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Tab,
  Tabs,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";

import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import type { GridColDef } from "@mui/x-data-grid";

import { api } from "../api/client";

type ApiPage<T> = {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
};

type CustomerItem = { id: number; code: string; name: string };
type SiteItem = { id: number; name: string };
type TechItem = { id: number; full_name: string; is_active: boolean };
type LookupItem = { id: number; label: string };

type PlanRow = {
  id: number;
  customer_code?: string;
  customer_name?: string;
  site_name?: string;
  inventory_hostname?: string | null;
  inventory_knumber?: string | null;
  inventory_serial_number?: string | null;
  title: string;
  next_due_date: string;
  last_done_date?: string | null;
  tech_name?: string | null;
  is_active: boolean;
  updated_at?: string | null;
};

type PlanDetail = PlanRow & {
  schedule_type: string;
  interval_unit?: string | null;
  interval_value?: number | null;
  fixed_month?: number | null;
  fixed_day?: number | null;
  alert_days_before: number;
  notes?: string | null;
  created_at?: string | null;
};

type EventRow = {
  id: number;
  performed_at: string;
  result: string;
  tech_name?: string | null;
  notes?: string | null;

  customer_code?: string;
  customer_name?: string;
  site_name?: string;
  inventory_hostname?: string | null;
  plan_title?: string | null;
  updated_at?: string | null;
};

type EventDetail = EventRow & {
  inventory?: number;
  plan?: number;
  tech?: number;
  created_at?: string | null;
};

type NotifRow = {
  id: number;
  due_date: string;
  sent_at: string;
  status: string;
  recipient_internal: string;
  recipient_tech: string;
  error_message?: string | null;

  customer_code?: string;
  customer_name?: string;
  inventory_hostname?: string | null;
  plan_title?: string;
  updated_at?: string | null;
};

type TemplateRow = {
  id: number;
  type_label?: string | null;
  title: string;
  schedule_type: string;
  interval_unit?: string | null;
  interval_value?: number | null;
  fixed_month?: number | null;
  fixed_day?: number | null;
  default_tech_name?: string | null;
  is_active: boolean;
  updated_at?: string | null;
  notes?: string | null;
};

type TechRow = {
  id: number;
  full_name: string;
  email?: string | null;
  phone?: string | null;
  is_active: boolean;
  notes?: string | null;
  updated_at?: string | null;
};

async function copyToClipboard(text: string) {
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.left = "-9999px";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    document.body.removeChild(ta);
  }
}

function FieldRow(props: { label: string; value?: string | null; mono?: boolean }) {
  const { label, value, mono } = props;
  const v = value ?? "";
  return (
    <Stack direction="row" spacing={1} alignItems="center" sx={{ py: 0.75 }}>
      <Box sx={{ width: 120, opacity: 0.7 }}>
        <Typography variant="body2">{label}</Typography>
      </Box>

      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Typography
          variant="body2"
          sx={{
            fontFamily: mono
              ? "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"
              : undefined,
            wordBreak: "break-word",
          }}
        >
          {v || "—"}
        </Typography>
      </Box>

      {v ? (
        <Tooltip title="Copia">
          <IconButton size="small" onClick={() => copyToClipboard(v)}>
            <ContentCopyIcon fontSize="inherit" />
          </IconButton>
        </Tooltip>
      ) : (
        <Box sx={{ width: 34 }} />
      )}
    </Stack>
  );
}

const asId = (v: unknown): number | "" => {
  const s = String(v);
  return s === "" ? "" : Number(s);
};

type DueFilter = "" | "overdue" | "next7" | "next30";

function PlansTab() {
  const [rows, setRows] = React.useState<PlanRow[]>([]);
  const [loading, setLoading] = React.useState(false);

  const [q, setQ] = React.useState("");
  const [search, setSearch] = React.useState("");

  const [customerId, setCustomerId] = React.useState<number | "">("");
  const [siteId, setSiteId] = React.useState<number | "">("");
  const [techId, setTechId] = React.useState<number | "">("");
  const [active, setActive] = React.useState<"" | "true" | "false">("");
  const [due, setDue] = React.useState<DueFilter>("");

  const [customers, setCustomers] = React.useState<CustomerItem[]>([]);
  const [sites, setSites] = React.useState<SiteItem[]>([]);
  const [techs, setTechs] = React.useState<TechItem[]>([]);

  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const [selectedId, setSelectedId] = React.useState<number | null>(null);
  const [detail, setDetail] = React.useState<PlanDetail | null>(null);
  const [detailLoading, setDetailLoading] = React.useState(false);
  const [events, setEvents] = React.useState<EventRow[]>([]);
  const [notifs, setNotifs] = React.useState<NotifRow[]>([]);
  const [subLoading, setSubLoading] = React.useState(false);

  const loadCustomers = React.useCallback(async () => {
    const res = await api.get<ApiPage<CustomerItem>>("/customers/", { params: { ordering: "name" } });
    setCustomers(res.data.results ?? []);
  }, []);

  const loadSites = React.useCallback(async () => {
    const params: any = { ordering: "name" };
    if (customerId !== "") params.customer = customerId;
    const res = await api.get<ApiPage<SiteItem>>("/sites/", { params });
    setSites(res.data.results ?? []);
  }, [customerId]);

  const loadTechs = React.useCallback(async () => {
    const res = await api.get<ApiPage<TechItem>>("/techs/", {
      params: { ordering: "last_name", page_size: 200 },
    });
    setTechs(res.data.results ?? []);
  }, []);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const params: any = {};
      if (search) params.search = search;
      if (customerId !== "") params.customer = customerId;
      if (siteId !== "") params.site = siteId;
      if (techId !== "") params.tech = techId;
      if (active !== "") params.is_active = active;
      if (due) params.due = due;
      const res = await api.get<ApiPage<PlanRow>>("/maintenance-plans/", { params });
      setRows(res.data.results ?? []);
    } finally {
      setLoading(false);
    }
  }, [search, customerId, siteId, techId, active, due]);

  const loadDetail = React.useCallback(async (id: number) => {
    setDetailLoading(true);
    setDetail(null);
    setEvents([]);
    setNotifs([]);
    try {
      const res = await api.get<PlanDetail>(`/maintenance-plans/${id}/`);
      setDetail(res.data);
    } finally {
      setDetailLoading(false);
    }
  }, []);

  const loadRelated = React.useCallback(async (planId: number) => {
    setSubLoading(true);
    try {
      const [ev, nf] = await Promise.all([
        api.get<ApiPage<EventRow>>("/maintenance-events/", {
          params: { plan: planId, ordering: "-performed_at", page_size: 5 },
        }),
        api.get<ApiPage<NotifRow>>("/maintenance-notifications/", {
          params: { plan: planId, ordering: "-sent_at", page_size: 5 },
        }),
      ]);
      setEvents(ev.data.results ?? []);
      setNotifs(nf.data.results ?? []);
    } finally {
      setSubLoading(false);
    }
  }, []);

  React.useEffect(() => {
    loadCustomers();
    loadTechs();
  }, [loadCustomers, loadTechs]);

  React.useEffect(() => {
    setSiteId("");
    loadSites();
  }, [customerId, loadSites]);

  React.useEffect(() => {
    load();
  }, [load]);

  const cols: GridColDef<PlanRow>[] = React.useMemo(
    () => [
      { field: "customer_code", headerName: "Cust", width: 110 },
      { field: "customer_name", headerName: "Customer", width: 220 },
      { field: "site_name", headerName: "Site", width: 170 },
      {
        field: "inventory_hostname",
        headerName: "Inventory",
        flex: 1,
        minWidth: 200,
        valueGetter: (v, row) => { void v; return row.inventory_hostname || row.inventory_knumber || row.inventory_serial_number || "—"; },
      },
      { field: "title", headerName: "Plan", width: 260 },
      { field: "next_due_date", headerName: "Next due", width: 140 },
      { field: "last_done_date", headerName: "Last done", width: 140 },
      { field: "tech_name", headerName: "Tech", width: 180 },
      {
        field: "is_active",
        headerName: "Active",
        width: 110,
        valueGetter: (v, row) => { void v; return row.is_active ? "Yes" : "No"; },
      },
      { field: "updated_at", headerName: "Updated", width: 180 },
    ],
    []
  );

  return (
    <>
      <Card>
        <CardContent>
          <Stack direction={{ xs: "column", md: "row" }} spacing={1.5} sx={{ mb: 2 }} alignItems="center">
            <TextField
              size="small"
              label="Search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") setSearch(q);
              }}
              sx={{ width: { xs: "100%", md: 340 } }}
            />

            <FormControl size="small" sx={{ minWidth: 200, width: { xs: "100%", md: 220 } }}>
              <InputLabel>Customer</InputLabel>
              <Select label="Customer" value={customerId} onChange={(e) => setCustomerId(asId(e.target.value))}>
                <MenuItem value="">All</MenuItem>
                {customers.map((c) => (
                  <MenuItem key={c.id} value={c.id}>
                    {c.code} — {c.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 200, width: { xs: "100%", md: 240 } }}>
              <InputLabel>Site</InputLabel>
              <Select label="Site" value={siteId} onChange={(e) => setSiteId(asId(e.target.value))}>
                <MenuItem value="">All</MenuItem>
                {sites.map((s) => (
                  <MenuItem key={s.id} value={s.id}>
                    {s.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 160, width: { xs: "100%", md: 200 } }}>
              <InputLabel>Due</InputLabel>
              <Select label="Due" value={due} onChange={(e) => setDue(String(e.target.value) as DueFilter)}>
                <MenuItem value="">All</MenuItem>
                <MenuItem value="overdue">Overdue</MenuItem>
                <MenuItem value="next7">Next 7 days</MenuItem>
                <MenuItem value="next30">Next 30 days</MenuItem>
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 180, width: { xs: "100%", md: 220 } }}>
              <InputLabel>Tech</InputLabel>
              <Select label="Tech" value={techId} onChange={(e) => setTechId(asId(e.target.value))}>
                <MenuItem value="">All</MenuItem>
                {techs.map((t) => (
                  <MenuItem key={t.id} value={t.id}>
                    {t.full_name}
                    {t.is_active ? "" : " (inactive)"}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 160, width: { xs: "100%", md: 180 } }}>
              <InputLabel>Active</InputLabel>
              <Select label="Active" value={active} onChange={(e) => setActive(String(e.target.value) as any)}>
                <MenuItem value="">All</MenuItem>
                <MenuItem value="true">Active</MenuItem>
                <MenuItem value="false">Inactive</MenuItem>
              </Select>
            </FormControl>

            <Button
              variant="outlined"
              onClick={() => {
                setQ("");
                setSearch("");
                setCustomerId("");
                setSiteId("");
                setTechId("");
                setDue("");
                setActive("");
              }}
              sx={{ width: { xs: "100%", md: "auto" } }}
            >
              Reset
            </Button>
          </Stack>

          <Box sx={{ height: 640 }}>
            <DataGrid
              rows={rows}
              columns={cols}
              loading={loading}
              disableRowSelectionOnClick
              slots={{ toolbar: GridToolbar }}
              slotProps={{ toolbar: { showQuickFilter: true, quickFilterProps: { debounceMs: 300 } } }}
              initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 } } }}
              pageSizeOptions={[10, 25, 50, 100]}
              onRowClick={(params) => {
                const rowId = Number(params.row.id);
                setSelectedId(rowId);
                setDrawerOpen(true);
                loadDetail(rowId);
                loadRelated(rowId);
              }}
            />
          </Box>
        </CardContent>
      </Card>

      <Drawer
        anchor="right"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        PaperProps={{ sx: { width: { xs: "100%", sm: 520 } } }}
      >
        <Stack sx={{ p: 2 }} spacing={1.5}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1}>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6">
                {detail?.title || (selectedId ? `Plan #${selectedId}` : "Plan")}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                {detail?.customer_code ? `${detail.customer_code} — ${detail.customer_name} • ${detail.site_name}` : " "}
              </Typography>
            </Box>

            <IconButton onClick={() => setDrawerOpen(false)}>
              <CloseIcon />
            </IconButton>
          </Stack>

          <Divider />

          {detailLoading ? (
            <Stack direction="row" alignItems="center" spacing={1} sx={{ py: 2 }}>
              <CircularProgress size={18} />
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                Caricamento dettaglio…
              </Typography>
            </Stack>
          ) : detail ? (
            <>
              <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap" }}>
                <Chip size="small" label={`Due: ${detail.next_due_date}`} />
                {detail.is_active ? <Chip size="small" label="Active" /> : <Chip size="small" label="Inactive" />}
                {detail.tech_name ? <Chip size="small" label={detail.tech_name} /> : null}
              </Stack>

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Inventory
              </Typography>
              <FieldRow label="Hostname" value={detail.inventory_hostname ?? ""} mono />
              <FieldRow label="K#" value={detail.inventory_knumber ?? ""} mono />
              <FieldRow label="Serial" value={detail.inventory_serial_number ?? ""} mono />

              <Divider />

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Schedule
              </Typography>
              <FieldRow label="Type" value={detail.schedule_type} mono />
              <FieldRow
                label="Interval"
                value={detail.interval_value && detail.interval_unit ? `${detail.interval_value} ${detail.interval_unit}` : ""}
                mono
              />
              <FieldRow
                label="Fixed"
                value={detail.fixed_month && detail.fixed_day ? `${detail.fixed_day}/${detail.fixed_month}` : ""}
                mono
              />
              <FieldRow label="Last done" value={detail.last_done_date ?? ""} mono />
              <FieldRow label="Alert" value={`${detail.alert_days_before} days`} mono />

              <Divider />

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Notes
              </Typography>
              <Typography variant="body2" sx={{ whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                {detail.notes || "—"}
              </Typography>

              <Divider />

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Recent events
              </Typography>
              {subLoading ? (
                <Typography variant="body2" sx={{ opacity: 0.7 }}>
                  loading…
                </Typography>
              ) : events.length ? (
                <Stack spacing={0.75}>
                  {events.map((e) => (
                    <Box key={e.id} sx={{ p: 1, border: "1px solid", borderColor: "divider", borderRadius: 2 }}>
                      <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="body2" sx={{ fontWeight: 700 }}>
                          {e.performed_at} • {e.result}
                        </Typography>
                        <Typography variant="body2" sx={{ opacity: 0.7 }}>
                          {e.tech_name || ""}
                        </Typography>
                      </Stack>
                      {e.notes ? (
                        <Typography variant="body2" sx={{ opacity: 0.8, mt: 0.5, whiteSpace: "pre-wrap" }}>
                          {e.notes}
                        </Typography>
                      ) : null}
                    </Box>
                  ))}
                </Stack>
              ) : (
                <Typography variant="body2" sx={{ opacity: 0.7 }}>
                  —
                </Typography>
              )}

              <Divider />

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Recent notifications
              </Typography>
              {subLoading ? (
                <Typography variant="body2" sx={{ opacity: 0.7 }}>
                  loading…
                </Typography>
              ) : notifs.length ? (
                <Stack spacing={0.75}>
                  {notifs.map((n) => (
                    <Box key={n.id} sx={{ p: 1, border: "1px solid", borderColor: "divider", borderRadius: 2 }}>
                      <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="body2" sx={{ fontWeight: 700 }}>
                          due {n.due_date} • {n.status}
                        </Typography>
                        <Typography variant="body2" sx={{ opacity: 0.7 }}>
                          {new Date(n.sent_at).toLocaleString()}
                        </Typography>
                      </Stack>
                      <Typography variant="body2" sx={{ opacity: 0.85, mt: 0.5 }}>
                        {n.recipient_internal} • {n.recipient_tech}
                      </Typography>
                      {n.error_message ? (
                        <Typography variant="body2" sx={{ opacity: 0.8, mt: 0.5, whiteSpace: "pre-wrap" }}>
                          {n.error_message}
                        </Typography>
                      ) : null}
                    </Box>
                  ))}
                </Stack>
              ) : (
                <Typography variant="body2" sx={{ opacity: 0.7 }}>
                  —
                </Typography>
              )}
            </>
          ) : (
            <Typography variant="body2" sx={{ opacity: 0.7 }}>
              Nessun dettaglio disponibile.
            </Typography>
          )}
        </Stack>
      </Drawer>
    </>
  );
}

function EventsTab() {
  const [rows, setRows] = React.useState<EventRow[]>([]);
  const [loading, setLoading] = React.useState(false);

  const [q, setQ] = React.useState("");
  const [search, setSearch] = React.useState("");

  const [customerId, setCustomerId] = React.useState<number | "">("");
  const [siteId, setSiteId] = React.useState<number | "">("");
  const [techId, setTechId] = React.useState<number | "">("");
  const [result, setResult] = React.useState<"" | "ok" | "ko">("");

  const [customers, setCustomers] = React.useState<CustomerItem[]>([]);
  const [sites, setSites] = React.useState<SiteItem[]>([]);
  const [techs, setTechs] = React.useState<TechItem[]>([]);

  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const [selectedId, setSelectedId] = React.useState<number | null>(null);
  const [detail, setDetail] = React.useState<EventDetail | null>(null);
  const [detailLoading, setDetailLoading] = React.useState(false);

  const loadCustomers = React.useCallback(async () => {
    const res = await api.get<ApiPage<CustomerItem>>("/customers/", { params: { ordering: "name" } });
    setCustomers(res.data.results ?? []);
  }, []);

  const loadSites = React.useCallback(async () => {
    const params: any = { ordering: "name" };
    if (customerId !== "") params.customer = customerId;
    const res = await api.get<ApiPage<SiteItem>>("/sites/", { params });
    setSites(res.data.results ?? []);
  }, [customerId]);

  const loadTechs = React.useCallback(async () => {
    const res = await api.get<ApiPage<TechItem>>("/techs/", {
      params: { ordering: "last_name", page_size: 200 },
    });
    setTechs(res.data.results ?? []);
  }, []);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const params: any = { ordering: "-performed_at" };
      if (search) params.search = search;
      if (customerId !== "") params.customer = customerId;
      if (siteId !== "") params.site = siteId;
      if (techId !== "") params.tech = techId;
      if (result !== "") params.result = result;
      const res = await api.get<ApiPage<EventRow>>("/maintenance-events/", { params });
      setRows(res.data.results ?? []);
    } finally {
      setLoading(false);
    }
  }, [search, customerId, siteId, techId, result]);

  const loadDetail = React.useCallback(async (id: number) => {
    setDetailLoading(true);
    setDetail(null);
    try {
      const res = await api.get<EventDetail>(`/maintenance-events/${id}/`);
      setDetail(res.data);
    } finally {
      setDetailLoading(false);
    }
  }, []);

  React.useEffect(() => {
    loadCustomers();
    loadTechs();
  }, [loadCustomers, loadTechs]);

  React.useEffect(() => {
    setSiteId("");
    loadSites();
  }, [customerId, loadSites]);

  React.useEffect(() => {
    load();
  }, [load]);

  const cols: GridColDef<EventRow>[] = React.useMemo(
    () => [
      { field: "performed_at", headerName: "Performed", width: 170 },
      { field: "result", headerName: "Result", width: 100 },
      { field: "customer_code", headerName: "Cust", width: 110 },
      { field: "customer_name", headerName: "Customer", width: 220 },
      { field: "site_name", headerName: "Site", width: 170 },
      { field: "inventory_hostname", headerName: "Inventory", width: 220 },
      { field: "plan_title", headerName: "Plan", flex: 1, minWidth: 220 },
      { field: "tech_name", headerName: "Tech", width: 180 },
      { field: "updated_at", headerName: "Updated", width: 180 },
    ],
    []
  );

  return (
    <>
      <Card>
        <CardContent>
          <Stack direction={{ xs: "column", md: "row" }} spacing={1.5} sx={{ mb: 2 }} alignItems="center">
            <TextField
              size="small"
              label="Search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") setSearch(q);
              }}
              sx={{ width: { xs: "100%", md: 340 } }}
            />

            <FormControl size="small" sx={{ minWidth: 200, width: { xs: "100%", md: 220 } }}>
              <InputLabel>Customer</InputLabel>
              <Select label="Customer" value={customerId} onChange={(e) => setCustomerId(asId(e.target.value))}>
                <MenuItem value="">All</MenuItem>
                {customers.map((c) => (
                  <MenuItem key={c.id} value={c.id}>
                    {c.code} — {c.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 200, width: { xs: "100%", md: 240 } }}>
              <InputLabel>Site</InputLabel>
              <Select label="Site" value={siteId} onChange={(e) => setSiteId(asId(e.target.value))}>
                <MenuItem value="">All</MenuItem>
                {sites.map((s) => (
                  <MenuItem key={s.id} value={s.id}>
                    {s.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 180, width: { xs: "100%", md: 220 } }}>
              <InputLabel>Tech</InputLabel>
              <Select label="Tech" value={techId} onChange={(e) => setTechId(asId(e.target.value))}>
                <MenuItem value="">All</MenuItem>
                {techs.map((t) => (
                  <MenuItem key={t.id} value={t.id}>
                    {t.full_name}
                    {t.is_active ? "" : " (inactive)"}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 150, width: { xs: "100%", md: 170 } }}>
              <InputLabel>Result</InputLabel>
              <Select label="Result" value={result} onChange={(e) => setResult(String(e.target.value) as any)}>
                <MenuItem value="">All</MenuItem>
                <MenuItem value="ok">OK</MenuItem>
                <MenuItem value="ko">KO</MenuItem>
              </Select>
            </FormControl>

            <Button
              variant="outlined"
              onClick={() => {
                setQ("");
                setSearch("");
                setCustomerId("");
                setSiteId("");
                setTechId("");
                setResult("");
              }}
              sx={{ width: { xs: "100%", md: "auto" } }}
            >
              Reset
            </Button>
          </Stack>

          <Box sx={{ height: 640 }}>
            <DataGrid
              rows={rows}
              columns={cols}
              loading={loading}
              disableRowSelectionOnClick
              slots={{ toolbar: GridToolbar }}
              slotProps={{ toolbar: { showQuickFilter: true, quickFilterProps: { debounceMs: 300 } } }}
              initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 } } }}
              pageSizeOptions={[10, 25, 50, 100]}
              onRowClick={(params) => {
                const rowId = Number(params.row.id);
                setSelectedId(rowId);
                setDrawerOpen(true);
                loadDetail(rowId);
              }}
            />
          </Box>
        </CardContent>
      </Card>

      <Drawer
        anchor="right"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        PaperProps={{ sx: { width: { xs: "100%", sm: 520 } } }}
      >
        <Stack sx={{ p: 2 }} spacing={1.5}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1}>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6">
                {selectedId ? `Event #${selectedId}` : "Event"}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                {detail?.customer_code ? `${detail.customer_code} — ${detail.customer_name} • ${detail.site_name}` : " "}
              </Typography>
            </Box>

            <IconButton onClick={() => setDrawerOpen(false)}>
              <CloseIcon />
            </IconButton>
          </Stack>

          <Divider />

          {detailLoading ? (
            <Stack direction="row" alignItems="center" spacing={1} sx={{ py: 2 }}>
              <CircularProgress size={18} />
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                Caricamento…
              </Typography>
            </Stack>
          ) : detail ? (
            <>
              <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap" }}>
                <Chip size="small" label={`${detail.performed_at} • ${detail.result}`} />
                {detail.tech_name ? <Chip size="small" label={detail.tech_name} /> : null}
              </Stack>

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Inventory / Plan
              </Typography>
              <FieldRow label="Inventory" value={detail.inventory_hostname ?? ""} mono />
              <FieldRow label="Plan" value={detail.plan_title ?? ""} />

              <Divider />

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Notes
              </Typography>
              <Typography variant="body2" sx={{ whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                {detail.notes || "—"}
              </Typography>
            </>
          ) : (
            <Typography variant="body2" sx={{ opacity: 0.7 }}>
              Nessun dettaglio disponibile.
            </Typography>
          )}
        </Stack>
      </Drawer>
    </>
  );
}

function NotificationsTab() {
  const [rows, setRows] = React.useState<NotifRow[]>([]);
  const [loading, setLoading] = React.useState(false);

  const [q, setQ] = React.useState("");
  const [search, setSearch] = React.useState("");

  const [customerId, setCustomerId] = React.useState<number | "">("");
  const [siteId, setSiteId] = React.useState<number | "">("");
  const [status, setStatus] = React.useState<"" | "pending" | "sent" | "error">("");

  const [customers, setCustomers] = React.useState<CustomerItem[]>([]);
  const [sites, setSites] = React.useState<SiteItem[]>([]);

  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const [selectedId, setSelectedId] = React.useState<number | null>(null);
  const [detail, setDetail] = React.useState<NotifRow | null>(null);
  const [detailLoading, setDetailLoading] = React.useState(false);

  const loadCustomers = React.useCallback(async () => {
    const res = await api.get<ApiPage<CustomerItem>>("/customers/", { params: { ordering: "name" } });
    setCustomers(res.data.results ?? []);
  }, []);

  const loadSites = React.useCallback(async () => {
    const params: any = { ordering: "name" };
    if (customerId !== "") params.customer = customerId;
    const res = await api.get<ApiPage<SiteItem>>("/sites/", { params });
    setSites(res.data.results ?? []);
  }, [customerId]);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const params: any = { ordering: "-sent_at" };
      if (search) params.search = search;
      if (customerId !== "") params.customer = customerId;
      if (siteId !== "") params.site = siteId;
      if (status !== "") params.status = status;
      const res = await api.get<ApiPage<NotifRow>>("/maintenance-notifications/", { params });
      setRows(res.data.results ?? []);
    } finally {
      setLoading(false);
    }
  }, [search, customerId, siteId, status]);

  const loadDetail = React.useCallback(async (id: number) => {
    setDetailLoading(true);
    setDetail(null);
    try {
      const res = await api.get<NotifRow>(`/maintenance-notifications/${id}/`);
      setDetail(res.data);
    } finally {
      setDetailLoading(false);
    }
  }, []);

  React.useEffect(() => {
    loadCustomers();
  }, [loadCustomers]);

  React.useEffect(() => {
    setSiteId("");
    loadSites();
  }, [customerId, loadSites]);

  React.useEffect(() => {
    load();
  }, [load]);

  const cols: GridColDef<NotifRow>[] = React.useMemo(
    () => [
      { field: "due_date", headerName: "Due", width: 140 },
      { field: "status", headerName: "Status", width: 120 },
      { field: "customer_code", headerName: "Cust", width: 110 },
      { field: "customer_name", headerName: "Customer", width: 220 },
      { field: "inventory_hostname", headerName: "Inventory", width: 220 },
      { field: "plan_title", headerName: "Plan", flex: 1, minWidth: 240 },
      { field: "sent_at", headerName: "Sent", width: 190 },
      { field: "updated_at", headerName: "Updated", width: 180 },
    ],
    []
  );

  return (
    <>
      <Card>
        <CardContent>
          <Stack direction={{ xs: "column", md: "row" }} spacing={1.5} sx={{ mb: 2 }} alignItems="center">
            <TextField
              size="small"
              label="Search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") setSearch(q);
              }}
              sx={{ width: { xs: "100%", md: 340 } }}
            />

            <FormControl size="small" sx={{ minWidth: 200, width: { xs: "100%", md: 220 } }}>
              <InputLabel>Customer</InputLabel>
              <Select label="Customer" value={customerId} onChange={(e) => setCustomerId(asId(e.target.value))}>
                <MenuItem value="">All</MenuItem>
                {customers.map((c) => (
                  <MenuItem key={c.id} value={c.id}>
                    {c.code} — {c.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 200, width: { xs: "100%", md: 240 } }}>
              <InputLabel>Site</InputLabel>
              <Select label="Site" value={siteId} onChange={(e) => setSiteId(asId(e.target.value))}>
                <MenuItem value="">All</MenuItem>
                {sites.map((s) => (
                  <MenuItem key={s.id} value={s.id}>
                    {s.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 170, width: { xs: "100%", md: 200 } }}>
              <InputLabel>Status</InputLabel>
              <Select label="Status" value={status} onChange={(e) => setStatus(String(e.target.value) as any)}>
                <MenuItem value="">All</MenuItem>
                <MenuItem value="pending">pending</MenuItem>
                <MenuItem value="sent">sent</MenuItem>
                <MenuItem value="error">error</MenuItem>
              </Select>
            </FormControl>

            <Button
              variant="outlined"
              onClick={() => {
                setQ("");
                setSearch("");
                setCustomerId("");
                setSiteId("");
                setStatus("");
              }}
              sx={{ width: { xs: "100%", md: "auto" } }}
            >
              Reset
            </Button>
          </Stack>

          <Box sx={{ height: 640 }}>
            <DataGrid
              rows={rows}
              columns={cols}
              loading={loading}
              disableRowSelectionOnClick
              slots={{ toolbar: GridToolbar }}
              slotProps={{ toolbar: { showQuickFilter: true, quickFilterProps: { debounceMs: 300 } } }}
              initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 } } }}
              pageSizeOptions={[10, 25, 50, 100]}
              onRowClick={(params) => {
                const rowId = Number(params.row.id);
                setSelectedId(rowId);
                setDrawerOpen(true);
                loadDetail(rowId);
              }}
            />
          </Box>
        </CardContent>
      </Card>

      <Drawer
        anchor="right"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        PaperProps={{ sx: { width: { xs: "100%", sm: 520 } } }}
      >
        <Stack sx={{ p: 2 }} spacing={1.5}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1}>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6">
                {selectedId ? `Notification #${selectedId}` : "Notification"}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                {detail?.customer_code ? `${detail.customer_code} — ${detail.customer_name}` : " "}
              </Typography>
            </Box>

            <IconButton onClick={() => setDrawerOpen(false)}>
              <CloseIcon />
            </IconButton>
          </Stack>

          <Divider />

          {detailLoading ? (
            <Stack direction="row" alignItems="center" spacing={1} sx={{ py: 2 }}>
              <CircularProgress size={18} />
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                Caricamento…
              </Typography>
            </Stack>
          ) : detail ? (
            <>
              <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap" }}>
                <Chip size="small" label={`due ${detail.due_date}`} />
                <Chip size="small" label={detail.status} />
              </Stack>

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Routing
              </Typography>
              <FieldRow label="Plan" value={detail.plan_title ?? ""} />
              <FieldRow label="Inventory" value={detail.inventory_hostname ?? ""} mono />
              <FieldRow label="Internal" value={detail.recipient_internal ?? ""} mono />
              <FieldRow label="Tech" value={detail.recipient_tech ?? ""} mono />

              <Divider />

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Delivery
              </Typography>
              <FieldRow label="Sent" value={detail.sent_at} mono />

              {detail.error_message ? (
                <>
                  <Divider />
                  <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                    Error
                  </Typography>
                  <Typography variant="body2" sx={{ whiteSpace: "pre-wrap" }}>
                    {detail.error_message}
                  </Typography>
                </>
              ) : null}
            </>
          ) : (
            <Typography variant="body2" sx={{ opacity: 0.7 }}>
              Nessun dettaglio disponibile.
            </Typography>
          )}
        </Stack>
      </Drawer>
    </>
  );
}

function TemplatesTab() {
  const [rows, setRows] = React.useState<TemplateRow[]>([]);
  const [loading, setLoading] = React.useState(false);

  const [q, setQ] = React.useState("");
  const [search, setSearch] = React.useState("");

  const [typeId, setTypeId] = React.useState<number | "">("");
  const [active, setActive] = React.useState<"" | "true" | "false">("");
  const [defaultTechId, setDefaultTechId] = React.useState<number | "">("");

  const [types, setTypes] = React.useState<LookupItem[]>([]);
  const [techs, setTechs] = React.useState<TechItem[]>([]);

  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const [selectedId, setSelectedId] = React.useState<number | null>(null);
  const [detail, setDetail] = React.useState<TemplateRow | null>(null);
  const [detailLoading, setDetailLoading] = React.useState(false);

  const loadTypes = React.useCallback(async () => {
    const res = await api.get<ApiPage<LookupItem>>("/inventory-types/", { params: { ordering: "label", page_size: 200 } });
    setTypes(res.data.results ?? []);
  }, []);

  const loadTechs = React.useCallback(async () => {
    const res = await api.get<ApiPage<TechItem>>("/techs/", {
      params: { ordering: "last_name", page_size: 200 },
    });
    setTechs(res.data.results ?? []);
  }, []);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const params: any = {};
      if (search) params.search = search;
      if (typeId !== "") params.type = typeId;
      if (active !== "") params.is_active = active;
      if (defaultTechId !== "") params.default_tech = defaultTechId;
      const res = await api.get<ApiPage<TemplateRow>>("/maintenance-templates/", { params });
      setRows(res.data.results ?? []);
    } finally {
      setLoading(false);
    }
  }, [search, typeId, active, defaultTechId]);

  const loadDetail = React.useCallback(async (id: number) => {
    setDetailLoading(true);
    setDetail(null);
    try {
      const res = await api.get<TemplateRow>(`/maintenance-templates/${id}/`);
      setDetail(res.data);
    } finally {
      setDetailLoading(false);
    }
  }, []);

  React.useEffect(() => {
    loadTypes();
    loadTechs();
  }, [loadTypes, loadTechs]);

  React.useEffect(() => {
    load();
  }, [load]);

  const cols: GridColDef<TemplateRow>[] = React.useMemo(
    () => [
      { field: "title", headerName: "Template", flex: 1, minWidth: 280 },
      { field: "type_label", headerName: "Type", width: 200 },
      { field: "schedule_type", headerName: "Schedule", width: 140 },
      {
        field: "interval_value",
        headerName: "Interval",
        width: 140,
        valueGetter: (v, row) => { void v; return row.interval_value && row.interval_unit ? `${row.interval_value} ${row.interval_unit}` : "—"; },
      },
      {
        field: "fixed_day",
        headerName: "Fixed",
        width: 120,
        valueGetter: (v, row) => { void v; return row.fixed_day && row.fixed_month ? `${row.fixed_day}/${row.fixed_month}` : "—"; },
      },
      { field: "default_tech_name", headerName: "Default tech", width: 200 },
      {
        field: "is_active",
        headerName: "Active",
        width: 110,
        valueGetter: (v, row) => { void v; return row.is_active ? "Yes" : "No"; },
      },
      { field: "updated_at", headerName: "Updated", width: 180 },
    ],
    []
  );

  return (
    <>
      <Card>
        <CardContent>
          <Stack direction={{ xs: "column", md: "row" }} spacing={1.5} sx={{ mb: 2 }} alignItems="center">
            <TextField
              size="small"
              label="Search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") setSearch(q);
              }}
              sx={{ width: { xs: "100%", md: 340 } }}
            />

            <FormControl size="small" sx={{ minWidth: 200, width: { xs: "100%", md: 240 } }}>
              <InputLabel>Type</InputLabel>
              <Select label="Type" value={typeId} onChange={(e) => setTypeId(asId(e.target.value))}>
                <MenuItem value="">All</MenuItem>
                {types.map((t) => (
                  <MenuItem key={t.id} value={t.id}>
                    {t.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 190, width: { xs: "100%", md: 220 } }}>
              <InputLabel>Default tech</InputLabel>
              <Select
                label="Default tech"
                value={defaultTechId}
                onChange={(e) => setDefaultTechId(asId(e.target.value))}
              >
                <MenuItem value="">All</MenuItem>
                {techs.map((t) => (
                  <MenuItem key={t.id} value={t.id}>
                    {t.full_name}
                    {t.is_active ? "" : " (inactive)"}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl size="small" sx={{ minWidth: 160, width: { xs: "100%", md: 180 } }}>
              <InputLabel>Active</InputLabel>
              <Select label="Active" value={active} onChange={(e) => setActive(String(e.target.value) as any)}>
                <MenuItem value="">All</MenuItem>
                <MenuItem value="true">Active</MenuItem>
                <MenuItem value="false">Inactive</MenuItem>
              </Select>
            </FormControl>

            <Button
              variant="outlined"
              onClick={() => {
                setQ("");
                setSearch("");
                setTypeId("");
                setDefaultTechId("");
                setActive("");
              }}
              sx={{ width: { xs: "100%", md: "auto" } }}
            >
              Reset
            </Button>
          </Stack>

          <Box sx={{ height: 640 }}>
            <DataGrid
              rows={rows}
              columns={cols}
              loading={loading}
              disableRowSelectionOnClick
              slots={{ toolbar: GridToolbar }}
              slotProps={{ toolbar: { showQuickFilter: true, quickFilterProps: { debounceMs: 300 } } }}
              initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 } } }}
              pageSizeOptions={[10, 25, 50, 100]}
              onRowClick={(params) => {
                const rowId = Number(params.row.id);
                setSelectedId(rowId);
                setDrawerOpen(true);
                loadDetail(rowId);
              }}
            />
          </Box>
        </CardContent>
      </Card>

      <Drawer
        anchor="right"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        PaperProps={{ sx: { width: { xs: "100%", sm: 520 } } }}
      >
        <Stack sx={{ p: 2 }} spacing={1.5}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1}>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6">
                {detail?.title || (selectedId ? `Template #${selectedId}` : "Template")}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                {detail?.type_label ? `${detail.type_label} • ${detail.schedule_type}` : " "}
              </Typography>
            </Box>

            <IconButton onClick={() => setDrawerOpen(false)}>
              <CloseIcon />
            </IconButton>
          </Stack>

          <Divider />

          {detailLoading ? (
            <Stack direction="row" alignItems="center" spacing={1} sx={{ py: 2 }}>
              <CircularProgress size={18} />
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                Caricamento…
              </Typography>
            </Stack>
          ) : detail ? (
            <>
              <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap" }}>
                {detail.is_active ? <Chip size="small" label="Active" /> : <Chip size="small" label="Inactive" />}
                {detail.default_tech_name ? <Chip size="small" label={detail.default_tech_name} /> : null}
              </Stack>

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Schedule
              </Typography>
              <FieldRow label="Type" value={detail.schedule_type} mono />
              <FieldRow
                label="Interval"
                value={detail.interval_value && detail.interval_unit ? `${detail.interval_value} ${detail.interval_unit}` : ""}
                mono
              />
              <FieldRow
                label="Fixed"
                value={detail.fixed_day && detail.fixed_month ? `${detail.fixed_day}/${detail.fixed_month}` : ""}
                mono
              />

              <Divider />

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Notes
              </Typography>
              <Typography variant="body2" sx={{ whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                {detail.notes || "—"}
              </Typography>
            </>
          ) : (
            <Typography variant="body2" sx={{ opacity: 0.7 }}>
              Nessun dettaglio disponibile.
            </Typography>
          )}
        </Stack>
      </Drawer>
    </>
  );
}

function TechsTab() {
  const [rows, setRows] = React.useState<TechRow[]>([]);
  const [loading, setLoading] = React.useState(false);

  const [q, setQ] = React.useState("");
  const [search, setSearch] = React.useState("");
  const [active, setActive] = React.useState<"" | "true" | "false">("");

  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const [selectedId, setSelectedId] = React.useState<number | null>(null);
  const [detail, setDetail] = React.useState<TechRow | null>(null);
  const [detailLoading, setDetailLoading] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const params: any = { ordering: "last_name" };
      if (search) params.search = search;
      if (active !== "") params.is_active = active;
      const res = await api.get<ApiPage<TechRow>>("/techs/", { params });
      setRows(res.data.results ?? []);
    } finally {
      setLoading(false);
    }
  }, [search, active]);

  const loadDetail = React.useCallback(async (id: number) => {
    setDetailLoading(true);
    setDetail(null);
    try {
      const res = await api.get<TechRow>(`/techs/${id}/`);
      setDetail(res.data);
    } finally {
      setDetailLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  const cols: GridColDef<TechRow>[] = React.useMemo(
    () => [
      { field: "full_name", headerName: "Tech", flex: 1, minWidth: 260 },
      { field: "email", headerName: "Email", width: 260 },
      { field: "phone", headerName: "Phone", width: 180 },
      {
        field: "is_active",
        headerName: "Active",
        width: 110,
        valueGetter: (v, row) => { void v; return row.is_active ? "Yes" : "No"; },
      },
      { field: "updated_at", headerName: "Updated", width: 180 },
    ],
    []
  );

  return (
    <>
      <Card>
        <CardContent>
          <Stack direction={{ xs: "column", md: "row" }} spacing={1.5} sx={{ mb: 2 }} alignItems="center">
            <TextField
              size="small"
              label="Search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") setSearch(q);
              }}
              sx={{ width: { xs: "100%", md: 340 } }}
            />

            <FormControl size="small" sx={{ minWidth: 160, width: { xs: "100%", md: 180 } }}>
              <InputLabel>Active</InputLabel>
              <Select label="Active" value={active} onChange={(e) => setActive(String(e.target.value) as any)}>
                <MenuItem value="">All</MenuItem>
                <MenuItem value="true">Active</MenuItem>
                <MenuItem value="false">Inactive</MenuItem>
              </Select>
            </FormControl>

            <Button
              variant="outlined"
              onClick={() => {
                setQ("");
                setSearch("");
                setActive("");
              }}
              sx={{ width: { xs: "100%", md: "auto" } }}
            >
              Reset
            </Button>
          </Stack>

          <Box sx={{ height: 640 }}>
            <DataGrid
              rows={rows}
              columns={cols}
              loading={loading}
              disableRowSelectionOnClick
              slots={{ toolbar: GridToolbar }}
              slotProps={{ toolbar: { showQuickFilter: true, quickFilterProps: { debounceMs: 300 } } }}
              initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 } } }}
              pageSizeOptions={[10, 25, 50, 100]}
              onRowClick={(params) => {
                const rowId = Number(params.row.id);
                setSelectedId(rowId);
                setDrawerOpen(true);
                loadDetail(rowId);
              }}
            />
          </Box>
        </CardContent>
      </Card>

      <Drawer
        anchor="right"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        PaperProps={{ sx: { width: { xs: "100%", sm: 520 } } }}
      >
        <Stack sx={{ p: 2 }} spacing={1.5}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1}>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="h6">
                {detail?.full_name || (selectedId ? `Tech #${selectedId}` : "Tech")}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                {detail ? (detail.is_active ? "Active" : "Inactive") : " "}
              </Typography>
            </Box>

            <IconButton onClick={() => setDrawerOpen(false)}>
              <CloseIcon />
            </IconButton>
          </Stack>

          <Divider />

          {detailLoading ? (
            <Stack direction="row" alignItems="center" spacing={1} sx={{ py: 2 }}>
              <CircularProgress size={18} />
              <Typography variant="body2" sx={{ opacity: 0.7 }}>
                Caricamento…
              </Typography>
            </Stack>
          ) : detail ? (
            <>
              <Stack direction="row" spacing={1} sx={{ flexWrap: "wrap" }}>
                {detail.email ? <Chip size="small" label={detail.email} /> : null}
                {detail.phone ? <Chip size="small" label={detail.phone} /> : null}
              </Stack>

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Details
              </Typography>
              <FieldRow label="Email" value={detail.email ?? ""} mono />
              <FieldRow label="Phone" value={detail.phone ?? ""} mono />

              <Divider />

              <Typography variant="subtitle2" sx={{ mt: 1, opacity: 0.75 }}>
                Notes
              </Typography>
              <Typography variant="body2" sx={{ whiteSpace: "pre-wrap" }}>
                {detail.notes || "—"}
              </Typography>
            </>
          ) : (
            <Typography variant="body2" sx={{ opacity: 0.7 }}>
              Nessun dettaglio disponibile.
            </Typography>
          )}
        </Stack>
      </Drawer>
    </>
  );
}

type TabKey = "plans" | "events" | "notifications" | "templates" | "techs";

export default function Maintenance() {
  const [tab, setTab] = React.useState<TabKey>("plans");

  return (
    <Stack spacing={2}>
      <Box>
        <Typography variant="h5">
          Manutenzione
        </Typography>
        <Typography variant="body2" sx={{ opacity: 0.7 }}>
          Piani, interventi, notifiche, template e tecnici.
        </Typography>
      </Box>

      <Card>
        <CardContent sx={{ pb: 0 }}>
          <Tabs
            value={tab}
            onChange={(_, v) => setTab(v)}
            variant="scrollable"
            allowScrollButtonsMobile
            sx={{
              minHeight: 40,
              "& .MuiTab-root": { minHeight: 40, textTransform: "none", fontWeight: 700 },
            }}
          >
            <Tab value="plans" label="Plans" />
            <Tab value="events" label="Events" />
            <Tab value="notifications" label="Notifications" />
            <Tab value="templates" label="Templates" />
            <Tab value="techs" label="Techs" />
          </Tabs>
        </CardContent>
      </Card>

      {tab === "plans" ? <PlansTab /> : null}
      {tab === "events" ? <EventsTab /> : null}
      {tab === "notifications" ? <NotificationsTab /> : null}
      {tab === "templates" ? <TemplatesTab /> : null}
      {tab === "techs" ? <TechsTab /> : null}
    </Stack>
  );
}
